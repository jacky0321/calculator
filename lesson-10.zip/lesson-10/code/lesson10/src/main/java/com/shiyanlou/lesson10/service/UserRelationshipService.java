package com.shiyanlou.lesson10.service;

import com.shiyanlou.lesson10.domain.UserRelationship;

public interface UserRelationshipService {
	public UserRelationship getRelationship(int userId);
}
