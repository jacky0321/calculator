package com.shiyanlou.lesson7.service;

import com.shiyanlou.lesson7.domain.UserRelationship;

public interface UserRelationshipService {
	public UserRelationship getRelationship(int userId);
}
