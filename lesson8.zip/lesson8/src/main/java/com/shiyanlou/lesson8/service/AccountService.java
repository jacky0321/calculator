package com.shiyanlou.lesson8.service;

import com.shiyanlou.lesson8.domain.TransferDetail;

public interface AccountService {
	public String transfer(TransferDetail transferDetail);
}
