package com.search.dao;


import org.apache.ibatis.annotations.Mapper;

import com.search.domain.User;

@Mapper
public interface UserMapper {
	
	User check(User user);
}
