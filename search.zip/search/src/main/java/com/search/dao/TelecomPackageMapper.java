package com.search.dao;

import org.apache.ibatis.annotations.Mapper;

import com.search.domain.TelecomPackage;

@Mapper
public interface TelecomPackageMapper {

	TelecomPackage search(String phoneNumber);
}
