package com.search.dao;


import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.search.domain.TelecomPackage;
import com.search.domain.User;

@Mapper
public interface ImportMapper {
	
	int upload(List<TelecomPackage> telecomPackages);
}
