package com.search.service;


import com.search.domain.TelecomPackage;

public interface TelecomPackageService {
	
	public TelecomPackage search(String phoneNumber);
}
