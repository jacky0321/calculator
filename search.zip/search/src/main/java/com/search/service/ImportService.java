package com.search.service;

import java.io.InputStream;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;

public interface ImportService {

	public int importByExcel(InputStream in, String fileName);
	
	public Workbook getWorkbook(InputStream inStr, String fileName);
}
