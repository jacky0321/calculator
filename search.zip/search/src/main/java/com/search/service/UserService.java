package com.search.service;


import com.search.domain.User;

public interface UserService {
	
	public boolean check(User user);
}
