package com.search.serviceImpl;

import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.search.dao.ImportMapper;
import com.search.domain.TelecomPackage;
import com.search.service.ImportService;

@Service
public class ImportServiceImpl implements ImportService {

	@Autowired
	private ImportMapper importMapper;
	
	public int importByExcel (InputStream in, String fileName) {
		List<TelecomPackage> telecomPackages = new ArrayList<>();
		// 创建Excel工作薄
		Workbook work = null;
		try {
			work = this.getWorkbook(in, fileName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if (work == null) {
			System.out.println("创建Excel工作薄为空！");
		}

		Sheet sheet = null;
		Row row = null;

		for (int i = 0; i < work.getNumberOfSheets(); i++) {
			sheet = work.getSheetAt(i);
			if (sheet == null) {
				continue;
			}

			for (int j = sheet.getFirstRowNum(); j <= sheet.getLastRowNum(); j++) {
				row = sheet.getRow(j);
				if (row == null || row.getFirstCellNum() == j) {
					continue;
				}

				DecimalFormat df = new DecimalFormat("0");

				String phoneNumber = df.format(row.getCell(0).getNumericCellValue());
				TelecomPackage telecomPackage = new TelecomPackage(phoneNumber, row.getCell(1).getStringCellValue());
				telecomPackages.add(telecomPackage);
			}
		}
		try {
			work.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		int N = 1000;
		int length = 0;
		int totalLength = telecomPackages.size();
		int count = (int) Math.ceil(telecomPackages.size() * 1.0 / N);

		for (int i = 0; i < count; i++) {
			List<TelecomPackage> tempList = new ArrayList<>();
			for(int j = i * N; j < (i + 1) * N && j < totalLength; j++) {
				tempList.add(telecomPackages.get(j));
			}
			
			int number = importMapper.upload(tempList);
			length += number;	
		}
		
		return length;
	}

	public Workbook getWorkbook(InputStream inStr, String fileName) {
		Workbook workbook = null;
		String fileType = fileName.substring(fileName.lastIndexOf("."));
		if (".xls".equals(fileType)) {
			try {
				workbook = new HSSFWorkbook(inStr);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (".xlsx".equals(fileType)) {
			try {
				workbook = new XSSFWorkbook(inStr);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			System.out.println("请上传excel文件！");
		}
		return workbook;
	}

}