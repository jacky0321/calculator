package com.search.serviceImpl;

import java.util.List;

import javax.jws.soap.SOAPBinding.Use;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.search.dao.UserMapper;
import com.search.domain.User;
import com.search.service.UserService;


@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserMapper userMapper;
	
	public boolean check(User user) {
		User real_user = userMapper.check(user);
		return real_user == null ? false : true;
	}
}
