package com.search.serviceImpl;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.search.dao.TelecomPackageMapper;
import com.search.domain.TelecomPackage;
import com.search.service.TelecomPackageService;


@Service
public class TelecomPackageServiceImpl implements TelecomPackageService{

	@Autowired
	private TelecomPackageMapper telecomPackageMapper;
		
	public TelecomPackage search(String phoneNumber) {
		TelecomPackage telecomPackage = telecomPackageMapper.search(phoneNumber);
		return telecomPackage;
	}
}
