package com.search.domain;


public class TelecomPackage {

	private String phoneNumber;
	private String content;
		
	public TelecomPackage() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TelecomPackage(String phoneNumber, String content) {
		super();
		this.phoneNumber = phoneNumber;
		this.content = content;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	@Override
	public String toString() {
		return "TelecomPackage [phoneNumber=" + phoneNumber + ", content=" + content + "]";
	}
}
