package com.search.controller;

import java.io.InputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.search.service.ImportService;

@Controller
public class ImportController {

    @Autowired
    private ImportService importService;


    @PostMapping(value = "/upload")
    @ResponseBody
    public ModelAndView uploadExcel(HttpServletRequest request) throws Exception {
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;

        MultipartFile file = multipartRequest.getFile("file");
        if (file.isEmpty()) {
            ModelAndView mav = new ModelAndView("upload_fail");
    		mav.addObject("reason", "文件不能为空");
            return mav;
        }
        InputStream inputStream = file.getInputStream();
        int number = importService.importByExcel(inputStream, file.getOriginalFilename());

        inputStream.close();

        ModelAndView mav = new ModelAndView("upload_success");
		mav.addObject("number", number);

		return mav;
    }

}