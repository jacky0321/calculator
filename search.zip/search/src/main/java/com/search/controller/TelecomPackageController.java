package com.search.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.search.domain.TelecomPackage;
import com.search.service.TelecomPackageService;

@Controller
public class TelecomPackageController {
	
	@Autowired
	private TelecomPackageService telecomPackageService;
	
	@PostMapping("telecomPackage")
	public ModelAndView search(@RequestParam String phoneNumber) {
		TelecomPackage telecomPackage = telecomPackageService.search(phoneNumber);
		ModelAndView mav;
		if(telecomPackage != null) {
			mav = new ModelAndView("search_success");
			mav.addObject("telecomPackage", telecomPackage);
		} else {
			mav = new ModelAndView("search_fail");
			mav.addObject("phoneNumber", phoneNumber);
		}

		return mav;

	}
	
}