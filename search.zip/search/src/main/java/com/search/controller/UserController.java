package com.search.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

import com.search.domain.User;
import com.search.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
			
	@PostMapping("user")
	public String check(User user, HttpServletRequest request) {
		boolean flag = userService.check(user);
		if(flag == false) {
			return "redirect:/admin";
		}
		request.getSession().setAttribute("name", user.getName());
        return "upload";
	}
}