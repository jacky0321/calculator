package com.shiyanlou.lesson5.mapper;

import com.shiyanlou.lesson5.domain.Hobby;

public interface UserHobbyMapper {

	public Hobby findHobbyById(int id);
}
